# Input Data

Input Data consists of **Train Data** (with labels) and **Test Data** (without labels). Test Labels are NOT included here - they are stored in `reference_data/` for the scoring program only.

## Structure

```
input_data/
├── train/          # Training data with labels
│   ├── grain1_x28y21-var7_8000_us_2x_2020-12-02T135904_corr.npz
│   ├── grain2_x28y21-var7_8000_us_2x_2020-12-02T135904_corr.npz
│   └── ...
└── test/           # Test data WITHOUT labels (only images)
    ├── grain100_x28y21-var7_8000_us_2x_2020-12-02T135904_corr.npz
    ├── grain101_x28y21-var7_8000_us_2x_2020-12-02T135904_corr.npz
    └── ...
```

## File Format

Each `.npz` file contains:
- **Training files** (`train/`):
  - `x`: Grain image (NumPy array) - shape `(252, 252, 3)` for RGB
  - `y`: Variety label (integer) - what to predict
  - `original_filename`: Original filename
  - `bands`: Spectral band info (if applicable)

- **Test files** (`test/`):
  - `x`: Grain image (NumPy array) - shape `(252, 252, 3)` for RGB
  - `original_filename`: Original filename
  - `bands`: Spectral band info (if applicable)
  - **NO `y` key** - labels are hidden in `reference_data/`

## Usage

The ingestion program will:
1. Load training data from `input_data/train/` to train the model
2. Load test data from `input_data/test/` to make predictions
3. Save predictions (without accessing test labels)

**Important**: The ingestion program should NOT have access to test labels. Only the scoring program can access them from `reference_data/`.